package com.practice.stockMarket1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockMarket1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
